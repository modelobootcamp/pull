* **Instructions**:

  * Using the attached SQLite file, use an inspector to collect the following information...

  * The names of all of the tables within the database.

  * The column names and data types for the `Salaries` table.
